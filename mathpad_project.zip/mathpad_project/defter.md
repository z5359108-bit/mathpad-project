# MathPad Defteri

## 1. Aritmetik işlem

> **Soru:** 3x^2  
> *(çözücü: `arithmetic`)*

**Sonuç:** $$3 x^{2}$$

**Çözüm adımları:**

1. **Verilen işlem**

   $$
   3 x^{2}
   $$

2. **Sonuç**

   $$
   3 x^{2}
   $$

## 2. Denklem çözümü

> **Soru:** 7x+2=0  
> *(çözücü: `algebra`)*

**Sonuç:** $$\left[ \left\{ x : - \frac{2}{7}\right\}\right]$$

**Çözüm adımları:**

1. **Denklemler**

   $$
   7 x + 2 = 0
   $$

2. **Bilinmeyenli terimler bir tarafta, sabitler diğer tarafta**

   $$
   7 x = -2
   $$

3. **Her iki tarafı 7'ye böl**

   $$
   \frac{ 7 x }{ 7 } = \frac{ -2 }{ 7 }
   $$

4. **Kök**

   $$
   x = - \frac{2}{7}
   $$

5. **Kontrol**

   $$
   x = - \frac{2}{7} \Rightarrow 0 = 0 \;\checkmark
   $$

6. **Çözüm kümesi**

   $$
   \left\{ x : - \frac{2}{7}\right\}
   $$

